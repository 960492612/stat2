export const isLogin = state => {
    return state.userInfo && state.userInfo.token != undefined && state.userInfo.token != '' && state.router.length > 0
}
export const id = state => state.userInfo && state.userInfo.id
export const loginName = state => state.userInfo && state.userInfo.name
export const pl = state => state.userInfo && state.userInfo.pl
export const mid = state => state.userInfo && state.userInfo.mid
export const platform = state => state.userInfo && (state.userInfo.platform == 'null' ? false : state.userInfo.platform)

export const router = state => state.router

export const selectedAdmin = state => state.selectedAdmin

export const currentLocation = state => state.currentLocation

export const language = state => state.language

export const changeAdmin = state => state.changeAdmin

export const changeProduct = state => state.changeProduct

export const changeTopChannels = state => state.changeTopChannels

export const changeSubChannels = state => state.changeSubChannels

export const changeDate = state => state.changeDate

export const baseDate = state => state.baseDate
