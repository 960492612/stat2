import cookie from 'js-cookie'
import storage from 'good-storage'
const state = {
    userInfo: cookie.getJSON('userInfo'),
    router: storage.session.get('router', []),
    // selectedAdmin: null,
    currentLocation: storage.session.get('currentLocation', ''),

    language: storage.get('language', 'zh-cn'),
    // 筛选
    changeAdmin: null,
    changeProduct: null,
    changeTopChannels: null,
    changeSubChannels: null,
    changeDate: null,

    baseDate: storage.get('baseDate', '2017-12-10')
}
export default state