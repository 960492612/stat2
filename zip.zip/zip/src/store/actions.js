
import * as types from './mutation-type'
import cookie from 'js-cookie'
import storage from 'good-storage'
// 字符串常量
const USERINFO = 'userInfo'
const ROUTER = 'router'

// 登录消息的保存
export const setLogin = ({ commit }, data) => {
    
    let time = new Date(new Date().getTime() + 2 * 60 * 60 * 1000)
    let login = {
        userInfo: { token: data.token, id: data.id, name: data.name, pl: data.pl, platform: data.platform },
        router: data.router
    }
    cookie.set(USERINFO, login.userInfo, { expires: time })
    storage.session.set(ROUTER, login.router)
    commit(types.SET_LOGIN, login)
}

export const setLogout = ({commit}) =>{
    cookie.remove(USERINFO)
    storage.remove(ROUTER)
    window.location.reload()
    commit(types.SET_LOGOUT)
}

export const changeLanguage = ({commit}, language)=>{
    storage.set('language', language)
    commit(types.SET_LANGUAGE, language)
}

// export const setSelectedAdmin({commit})