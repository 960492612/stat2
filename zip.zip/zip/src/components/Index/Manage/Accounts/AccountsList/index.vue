<template>
  <div>
    <div class="account-list">
      <el-table :data="tableData" style="width:500px;" :row-class-name="currentUser">
        <div slot="empty">
          <i class="el-icon-loading" v-show="loadStatus == 1"></i> {{loadingText}}</div>
        <el-table-column prop="name" label="用户名" width="100" align="center">
        </el-table-column>
        <el-table-column prop="pl" label="权限等级" width="80" align="center">
        </el-table-column>
        <el-table-column prop="platform.name" label="部门" width="120" align="center">
        </el-table-column>
        <el-table-column prop="oper" label="操作" align="center">
          <template slot-scope="scope">
            <el-button @click.native.prevent="editRow(scope.row)" type="text">
              修改
            </el-button>
            <el-button @click.native.prevent="deleteRow(scope.row, scope.$index)" type="text">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { getAllUsers, addUser, deleteUser } from "api/account";
export default {
  data() {
    return {
      tableData: [],
      loadStatus: 1,
      platforms: []
    };
  },
  computed: {
    isManage() {
      return this.id == 5;
    },
    loadingText() {
      return this.loadStatus == 1 ? "加载中" : "暂无数据";
    },
    ...mapGetters(["id", "pl", "loginName"])
  },
  created() {
    this._getAllUsers();
  },
  methods: {
    _getAllUsers() {
      getAllUsers().then(res => {
        if (res.code == 1) {
          this.tableData = res.data;
        }
      });
    },
    editRow(item) {
      if (item.pl != this.pl) {
        this.$message.error("该账户您不可进行修改！");
        return;
      }
      this.$router.push({
        name: "EditAccount",
        params: { oldName: item.name, pid: item.pid }
      });
    },
    deleteRow(item, index) {
      if (item.pl != this.pl && this.pl < 5) {
        this.$message.error("该账户您无权删除！");
        return;
      }
      this.$confirm("此操作将永久删除该用户以及该用户所有的推广记录, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "error"
      })
        .then(() => {
          deleteUser({ id: item.id, userPl: this.pl }).then(res => {
            if (res.code == 1) {
              this.$message({
                type: "success",
                message: "删除成功!"
              });
              this.tableData.splice(index, 1);
            } else {
              this.$message.error("删除失败");
            }
          });
        })
        .catch((err) => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    currentUser({ row }) {
      if (row.id == this.id) {
        return "current";
      }
    }
  }
};
</script>
<style lang="scss">
.account-list {
  margin-top: 20px;
  .current {
    background: #f0f9eb;
  }
}
</style>


