<template>
  <div class="addProduct" v-loading="working" element-loading-text="正在努力添加.." element-loading-spinner="el-icon-loading">
    <el-form :model="data" status-icon label-position="right" label-width="80px" :rules="rules" ref="form" class="form">
      <el-form-item label="用户名:" prop="name" align="left">
        <el-input v-model="data.name" placeholder="填写唯一的用户名" style="width:50%;"></el-input>
      </el-form-item>
      <el-form-item label="权限:" prop="pl" align="left">
        <el-select v-model="data.pl" placeholder="选择角色" style="width:50%;">
          <el-option v-for="item in pls" :key="item.id" :label="item.name" :value="item.id">{{item.name}}</el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="部门:" prop="pid" align="left">
        <el-select v-model="data.pid" placeholder="选择部门" style="width:50%;">
          <el-option v-for="item in platforms" :key="item.id" :label="item.name" :value="item.id">{{item.name}}</el-option>
        </el-select>
      </el-form-item>
      <el-form-item align="left">
        <submit :submitAbled="submitAbled" @click="submit"></submit>
      </el-form-item>
    </el-form>

  </div>
</template>
<script>

import { debounce } from "common/js/util";
import { hasUser, addUser ,getPlatforms } from "api/account";
import { mapGetters } from "vuex";
import Submit from "base/Submit";
export default {
  data() {
    var _hasKey = (rule, value, callback) => {
        this._debounce(value, callback)
    };
    return {
      data: {
        name: null,
        pl: null,
        pid: null
      },
      rules: {
        name: [
          { required: true, message: "不能为空", trigger: "blur" },
          { validator: _hasKey, trigger: "change" }
        ],
        pl:[
          {required: true, message: "不能为空", trigger: 'blur'}
        ],
        pid:[
          {required: true, message: "不能为空", trigger: 'blur'}
        ]
      },
      pls: [{ id: 1, name: "推广员" }, { id: 5, name: "管理员" }],
      platforms: [],
      working: false,
      submitAbled: true
    };
  },
  created() {
    this._debounce = this._hasKey();
    this._getPlatforms()
  },
  computed: {
    ...mapGetters(["id", "pl"])
  },
  mounted() {},
  methods: {
    _hasKey() {
      return debounce((value, callback) => {
        hasUser(value).then(res => {
          if (res.code == 1) {
            callback(new Error("已存在该用户名"));
          } else {
            callback();
          }
        });
      }, 300);
    },
    _getPlatforms(){
      getPlatforms().then(res=>{
        if(res.code == 1){
          this.platforms = res.data
        }
      })
    },
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this._addUser();
        }
      });
    },
    _addUser(){
      addUser({...this.data, ...{userPl: this.pl}}).then(res=>{
        if (res.code == 1) {
          this.$message({
            message: `添加成功，默认密码是${res.data.default_pwd}`,
            type: "success",
            onClose: () => {
              this.$router.push({ name: "Accounts" });
            }
          });
        } else {
          this.$message("添加失败");
          this.submitAbled = true;
        }
      })
    }
  },
  components: {
    Submit
  }
};
</script>
<style lang="scss" scoped>
.addProduct {
  margin-top: 20px;
  width: 50%;
  .form {
    // border-bottom: 1px solid #eee;
  }
}
</style>
