<template>
  <statis-single-list />
</template>
<script>
import StatisSingleList from 'components/Index/Admin/Statis/StatisSingleList'
export default {
  created(){
    if (!this.$route.params.data) {
      this.$router.push({ name: "Statis" });
    }
  },
  components:{
    StatisSingleList
  }
}
</script>

