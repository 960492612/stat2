<template>
  <div class="statis">
    <search />
    <!-- 每个元主题的记录总表 -->
    <statis />
  </div>
</template>
<script>
import Statis from "components/Common/Statis";
import Search from "base/Search/manageSearch";
export default {
  components: {
    Search,
    Statis
  }
};
</script>
<style lang="scss">
</style>

