<template>
  <div>
    <subMenu :topMenuName="`Statis`"></subMenu>
    <transition name="fade" mode="out-in">
        <router-view></router-view>
      </transition>
    <!-- <router-view/> -->

  </div>
</template>
<script>
import subMenu from "base/subMenu";

export default {
  name: "Statis",
  components: {
    subMenu
  }
};
</script>
<style lang="scss" scoped>
.fade-enter-active, .fade-leave-active {
  transition: opacity .5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>

