<template>
  <product/>
</template>
<script>
import Product from 'components/Index/Admin/Products/AddProduct'
export default {
  components:{
    Product
  }
}
</script>
