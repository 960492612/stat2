<template>
  <product/>
</template>
<script>
import Product from 'components/Index/Admin/Products/ProductsList'
export default {
  components:{
    Product
  }
}
</script>

