<template>
  <div>
    <div class="content">
      <el-table :data="tableData" style="width:500px;">
        <div slot="empty">
          <i class="el-icon-loading" v-show="loadStatus == 1"></i> {{loadingText}}</div>
        <el-table-column prop="name" :label="$t('accountList.label.name')" width="100" align="center">
        </el-table-column>
        <el-table-column prop="pl" :label="$t('accountList.label.pl')" width="120" align="center">
        </el-table-column>
        <el-table-column prop="platform" :label="$t('accountList.label.platform')" width="120" align="center">
        </el-table-column>
        <el-table-column prop="oper" :label="$t('accountList.label.oper')" align="center">
          <template slot-scope="scope">
            <el-button @click.native.prevent="editRow(scope.row)" type="text">
              {{$t('accountList.label.edit')}}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      tableData: [],
      loadStatus: 1
    };
  },
  computed: {
    isManage() {
      return this.id == 5;
    },
    loadingText() {
      return this.loadStatus == 1 ? this.$t('data.loading') : this.$t('data.none');
    },
    ...mapGetters(["id", "pl", "loginName", "platform"])
  },
  created() {
    this.tableData.push({
      name: this.loginName,
      pl: this.pl,
      platform: this.platform.name
    });
  },
  methods: {
    _getAccounts() {},
    editRow(item) {
      if (item.pl != this.pl) {
        this.$message.error(this.$t('accountList.error.edit'));
        return;
      }
      this.$router.push({ name: "EditAccount" });
    }
  }
};
</script>
<style lang="scss" scoped>
.content {
  margin-top: 20px;
}
</style>


