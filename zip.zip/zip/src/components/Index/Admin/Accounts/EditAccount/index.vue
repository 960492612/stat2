<template>
    <div class="editAccount" v-loading="working" element-loading-text="正在努力.." element-loading-spinner="el-icon-loading">
        <el-form :model="data" status-icon label-position="right" label-width="100px" :rules="rules" ref="form" class="form">
            <el-form-item label="用户名:" prop="newName">
                <el-input v-model="data.newName" placeholder="填写新用户名"></el-input>
            </el-form-item>
            <el-form-item label="旧密码:" prop="oldPwd">
                <el-input v-model="data.oldPwd" placeholder="填写旧密码" type="password"></el-input>
            </el-form-item>
            <el-form-item label="新密码:" prop="newPwd">
                <el-input v-model="data.newPwd" placeholder="填写新密码" type="password"></el-input>
            </el-form-item>
            <el-form-item label="确认新密码:" prop="confirmNewPwd">
                <el-input v-model="data.confirmNewPwd" placeholder="确认新密码" type="password"></el-input>
            </el-form-item>
            <el-form-item align="left">
                <submit :submitAbled="submitAbled" @click="submit"></submit>
            </el-form-item>
        </el-form>

    </div>
</template>
<script>
// import { registerStat, hasKey, updateStat } from "api/updateStat";
import { debounce } from "common/js/util";
import { hasUser, editUser } from "api/account";
import { mapGetters } from "vuex";
import Submit from "base/Submit";
export default {
  data() {
    var _hasKey = (rule, value, callback) => {
      if (value == this.loginName) {
        callback();
      } else {
        this._debounce(value, callback);
      }
    };
    var confirmNewPwd = (rule, value, callback) => {
      if (value !== this.data.newPwd) {
        callback(new Error("两次新密码输入不一致！"));
      } else {
        callback();
      }
    };
    return {
      data: {
        oldName: null,
        newName: null,
        oldPwd: null,
        newPwd: null,
        confirmNewPwd: null
      },
      rules: {
        newName: [
          { required: true, message: "不能为空", trigger: "change" },
          { validator: _hasKey, trigger: "change" }
        ],
        oldPwd: [{ required: true, message: "不能为空", trigger: "blur" }],
        newPwd: [{ required: true, message: "不能为空", trigger: "blur" }],
        confirmNewPwd: [
          { required: true, message: "不能为空", trigger: "blur" },
          { validator: confirmNewPwd, trigger: "change" }
        ]
      },
      working: false,
      submitAbled: true
    };
  },
  created() {
    this._debounce = this._hasKey();
    this.data.oldName = this.data.newName = this.loginName
  },
  computed: {
    ...mapGetters(["id", "loginName"])
  },
  mounted() {},
  methods: {
    _hasKey() {
      return debounce((value, callback) => {
        hasUser(value).then(res => {
          if (res.code == 1) {
            callback(new Error("已存在该用户名"));
          } else {
            callback();
          }
        });
      }, 300);
    },
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this._editUser();
        }
      });
    },
    _editUser() {
      editUser(this.data).then(res => {
        if (res.code == 1) {
          this.$message({
            message: "修改成功",
            type: "success",
            onClose: () => {
              this.$router.push({ name: "Account" });
            }
          });
        } else {
          this.$message("修改失败");
        }
      });
    }
  },
  components: {
    Submit
  }
};
</script>
<style lang="scss" scoped>
.editAccount {
  margin-top: 20px;
  width: 50%;
  .form {
    // border-bottom: 1px solid #eee;
  }
}
</style>
