<template>
    <add-channels/>
</template>
<script>
import AddChannels from "components/Index/Admin/Channels/AddChannels";
export default {
  components: {
    AddChannels
  }
};
</script>

