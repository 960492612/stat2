<template>
  <div class="TraceStatisList">
    <div class="search-tool">
      <span class="label1">选择日期段查询该段时间的访问数据:</span>

      <el-date-picker v-model="dateRange" type="daterange" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerOptions">
      </el-date-picker>

      <el-select v-model="selectedKey" filterable clearable placeholder="选择推广条目" class="select">
        <el-option v-for="(item, index) in datas" :key="index" :value="item.key" :label="item.key"></el-option>
      </el-select>
    </div>
    <el-table :data="tableDatas" show-summary>
      <div slot="empty">
        <i class="el-icon-loading" v-show="loadStatus == 1"></i> {{loadingText}}</div>
      <el-table-column label="条目名" prop="key" align="left"></el-table-column>
      <el-table-column label="PV总数" prop="pv" align="left" sortable></el-table-column>
      <el-table-column label="UV总数" prop="uv" align="left" sortable></el-table-column>
      <el-table-column label="注册时间" prop="time" align="left" sortable ></el-table-column>
    </el-table>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import {
  getAllVisitsByOid,
//   getAllVisitsByPlatform,
//   getAllVisits
} from "api/trace";
import { formatTime,shortcuts ,isInDateRange} from "common/js/util";
export default {
  data() {
    return {
      datas: [],
      loadStatus: 1,
      dateRange: null,
      selectedKey: "",
      pickerOptions: {
        shortcuts
      }
    };
  },
  computed: {
    // 计算结果并构建成表格可用的数据
    tableDatas() {
      let ret = [];

      for (let i in this.datas) {
        let item = this.datas[i];
        if (this.selectedKey && item.key != this.selectedKey) {
          continue;
        }
        let obj = { key: item.key, pv: 0, uv: 0, time: item.time };
        if (!this.dateRange) {
          // 没有选择日期就返回全部
          obj["pv"] = Object.values(item.pvdata).reduce((total, num) => {
            return total + num;
          });
          obj["uv"] = Object.values(item.uvdata).reduce((total, num) => {
            return total + num;
          });
        } else {
          let start = this.dateRange[0];
          let end = this.dateRange[1];

          Object.entries(item.pvdata).forEach(_item => {
            // 选择在日期区间段的
            if (isInDateRange(start, end, new Date(_item[0]))) {
              obj["pv"] += _item[1];
            }
          });
          Object.entries(item.uvdata).forEach(_item => {
            // 选择在日期区间段的
            if (isInDateRange(start, end, new Date(_item[0]))) {
              obj["uv"] += _item[1];
            }
          });
        }
        ret.push(obj);
      }
      return ret;
    },
    loadingText() {
      return this.loadStatus == 1 ? "加载中" : "暂无数据";
    },
    ...mapGetters(["id", "pl"])
  },
  created() {
    this._getAllVisitsByOid(this.id);
  },
  methods: {
    _getAllVisitsByOid(id) {
      getAllVisitsByOid(id).then(res => {
        if (res.code == 1) {
          if (res.data.length == 0) {
            this.loadStatus = 0;
            this.datas = [];
            return;
          }
          // 序列化数据
          // console.log(res.data);
          this.datas = this.setDatas(this.groupByKey(res.data));
        } else {
          this.$message.error("加载失败");
          this.loadStatus = 0;
        }
      });
    },
    _getAllVisits() {
      getAllVisits().then(res => {
        if (res.code == 1) {
          // 序列化数据
          this.setPv(this.groupByKey(res.data));
          //   this.loadChart();
        } else {
          this.$message.error("加载失败");
        }
        this.loading = false;
      });
    },
    groupByKey(data) {
      let ret = {};
      data.forEach(item => {
        if (ret[item.key] === undefined) {
          ret[item.key] = {
            key: item.key,
            datas: [item],
            time: formatTime(item.rTime)
          };
        } else {
          ret[item.key].datas.push(item);
        }
      });
      // 返回的数组
      return Object.values(ret);
    },
    sortByDate(data) {
      data.sort((a, b) => {
        return a.time - b.time;
      });
    },
    setDatas(data) {
      let ret = [];

      for (let i in data) {
        // this.legends.push(data[i].key);
        let countByDay = {};
        let itemsByDay = {};
        // 先按日期排序一波
        this.sortByDate(data[i].datas);
        data[i].datas.forEach(item => {
          let date = formatTime(item.time);

          countByDay[date] === undefined
            ? (countByDay[date] = 1)
            : ++countByDay[date];
          itemsByDay[date] === undefined
            ? (itemsByDay[date] = { date: date, datas: [item] })
            : itemsByDay[date].datas.push(item);
        });
        // 分日期算出有多少个不同的agent,即uv数据
        for (let i in itemsByDay) {
          let countByAgent = {};
          itemsByDay[i].count = 0;
          itemsByDay[i].datas.forEach(item => {
            if (countByAgent[item.agent_token] === undefined) {
              countByAgent[item.agent_token] = 1;
              itemsByDay[i].count++;
            }
          });
        }
        // 重新构建合适的json对象
        let countByDay_ = {};
        for (let key in itemsByDay) {
          countByDay_[itemsByDay[key].date] = itemsByDay[key].count;
        }

        ret.push({
          key: data[i].key,
          pvdata: countByDay,
          uvdata: countByDay_,
          time: data[i].time
        });

        // ret.push(serie);
      }
      return ret;
    },
  },
};
</script>
<style lang="scss" scoped>
.TraceStatisList {
  // border-top: 1px solid #eee;
  margin-top: 20px;
  // padding-top: 25px;
  .search-tool {
    padding-bottom: 20px;
    border-bottom: 1px solid #ddd;
    text-align: left;
    .label1 {
      font-size: 14px;
      margin-right: 15px;
    }
    .label2 {
      font-size: 14px;
      margin-left: 15px;
    }
    .tip {
      margin-left: 5px;
    }
    .select {
      width: 135px;
    }
  }
}
</style>

