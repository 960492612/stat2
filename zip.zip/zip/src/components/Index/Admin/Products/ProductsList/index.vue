<template>
  <div>
    <div class="content">
      <el-table :data="tableData" style="width:770px;">
        <div slot="empty">
          <i class="el-icon-loading" v-show="loadStatus == 1"></i> {{loadingText}}</div>
        <el-table-column prop="id" :label="$t('product.label.id')" width="80" align="center">
        </el-table-column>
        <el-table-column prop="name" :label="$t('product.label.name')" width="180" align="center">
        </el-table-column>
        <el-table-column prop="category" :label="$t('product.label.category')" width="180" align="center" sortable >
        </el-table-column>
        <el-table-column prop="desc" :label="$t('product.label.desc')" width="180" align="center">
        </el-table-column>
        <el-table-column prop="oper" :label="$t('oper.oper')" align="center">
          <template slot-scope="scope">
            <el-button @click.native.prevent="editRow(scope.$index)" type="text">
              {{$t('oper.edit')}}
            </el-button>
            <el-button @click.native.prevent="deleteRow(scope.row, scope.$index)" type="text">
              {{$t('oper.delete')}}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { getProducts, deleteProduct } from "api/product";
import { mapActions, mapGetters } from "vuex";
export default {
  name: "Products",
  data() {
    return {
      tableData: [],
      loadStatus: 1
    };
  },
  computed: {
    loadingText() {
      return this.loadStatus == 1 ? this.$t('data.loading') : this.$t('data.none');
    },
    ...mapGetters(["id"])
  },
  created() {
    this._getProduct();
  },
  methods: {
    _getProduct() {
      getProducts().then(res => {
        if (res.code == 1) {
          if (res.data.length == 0) {
            this.loadStatus = 0;
            return;
          }
          this.tableData = res.data;
        } else {
          this.loadStatus = 0;
        }
      });
    },
    editRow(index) {
      this.$router.push({
        name: "UpdateProduct",
        params: this.tableData[index]
      });
    },
    deleteRow(row, index) {
      if (row.owner != this.id) {
        this.$message.error(this.$t('product.delete.disabled'));
        return;
      }
      this.$confirm(this.$t('product.delete.confirm'), this.$t('product.delete.tip'), {
        confirmButtonText: this.$t('product.delete.sure'),
        cancelButtonText: this.$t('product.delete.cancel'),
        type: "warning"
      })
        .then(() => {
          deleteProduct({ id: row.id, owner: this.id }).then(res => {
            if (res.code == 1) {
              this.$message({
                type: "success",
                message: this.$t('product.delete.success')
              });
              this.tableData.splice(index, 1);
            } else {
              this.$message.error(this.$t('product.delete.error'));
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: this.$t('product.delete.canceled')
          });
        });
    }
  },
};
</script>
<style lang="scss" scoped>
.content {
  margin-top: 20px;
  text-align: left;
  .second-content {
    li {
      height: 30px;
      line-height: 30px;
      border-bottom: 1px solid #eee;
      span {
        padding-left: 10px;
        display: inline-block;
        width: 166px;
      }
    }
  }
}
</style>
