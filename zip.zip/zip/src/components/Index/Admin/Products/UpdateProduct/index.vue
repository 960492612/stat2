<template>
    <add-product/>
</template>
<script>
import AddProduct from "components/Index/Admin/Products/AddProduct";
export default {
  components: {
    AddProduct
  }
};
</script>

