<template>
  <div class="statis">
    <!-- <search /> -->
    
    <statis />
  </div>
</template>
<script>
// import Statis from "components/Common/Statis";
// import Search from "base/Search/adminSearch";
import Statis from 'components/Common/StatisByChannel'
export default {
  components: {
    // Search,
    Statis
  }
};
</script>
<style lang="scss">
</style>