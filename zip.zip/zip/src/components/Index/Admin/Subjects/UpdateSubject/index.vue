<template>
  <register-subject :propData="data" :isEdit="true" :sid="sid" />
</template>
<script>
import RegisterSubject from "components/Index/Admin/Subjects/RegisterSubject";
export default {
  data() {
    return {
      data: {},
      sid: 0
    };
  },
  created() {
    if (!this.$route.params.hasOwnProperty("content")) {
      this.$router.push({ name: "Subjects" });
      return;
    }
    let subject = this.$route.params;
    this.data = this.generatorData(subject);
    this.sid = subject.sid;
    // console.log(subject);
  },
  methods: {
    generatorData(data) {
      let ret = {
        content: data.content,
        recentRecordTime: data.recentRecordTime,
        time: new Date(Number(data.time)),
        product: data.pid,
        channels: [],
        link: {},
        topChannels: null
      };
      // 暂存顶级渠道
      let topChannels = [];
      data.channels.forEach(item => {
        topChannels.push({ id: item.pCid, name: item.parentChannel });
        ret.channels.push(item.channels);
        ret.link[item.channels] = item.link;
      });
      ret.topChannels = unique(topChannels);
      return ret;
    }
  },
  components: {
    RegisterSubject
  }
};
function isEmpty(obj) {
  for (var key in obj) {
    return false;
  }
  return true;
}
function unique(arr) {
  let ret = [];
  let obj = {};
  for (let i in arr) {
    if (!obj[arr[i].id]) {
      ret.push(arr[i]);
      obj[arr[i].id] = 1;
    }
  }
  return ret;
}
</script>

