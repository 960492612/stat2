<template>
  <div class="AddTrace" v-loading="working" element-loading-text="正在努力添加.." element-loading-spinner="el-icon-loading">
    <el-form :model="data" status-icon label-position="right" label-width="100px" :rules="rules" ref="form" class="form">
      <el-form-item label="记录名:" prop="key" required>
        <el-input v-model="data.key" placeholder="填写唯一的名字用于该推广链接的记录,建议加属于自己的前缀" :disabled="isEdit"></el-input>
      </el-form-item>
      <el-form-item label="网址:" prop="url" required>
        <el-input v-model="data.url" placeholder="填写推广链接的完整网址"></el-input>
      </el-form-item>
      <el-form-item label="描述:" prop="desc">
        <el-input v-model="data.desc" placeholder="简短的描述"></el-input>
      </el-form-item>
      <el-form-item label="域名:" prop="domain">
        <el-select v-model="data.domain" placeholder="" style="width:100%;">
          <el-option v-for="(item, index) in domains" :key="index" :value="item.domain" :label="item.domain" >
            <span style="float: left">{{ item.domain }}</span>
            <span style="float: right; color: #8492a6; font-size: 13px">{{ item.desc }}</span>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="重要度：" prop="desc">
        <el-tooltip class="item" effect="dark" content="排序基准" placement="top">
          <el-rate v-model="data.degree" allow-half show-score class="rate"></el-rate>
        </el-tooltip>

      </el-form-item>
      <el-form-item align="left">
        <el-button type="primary" @click="submit">{{isEdit?'修改':'生成'}}统计链接</el-button>
      </el-form-item>
    </el-form>
    <div class="result" v-show="result != ''">
      <span>以下链接用于进行实际推广：</span>
      <el-button @click="copy" size="small" :data-clipboard-text="result" ref="copy">复制到剪切板</el-button>
      <p v-text="result" class="resultText"></p>
    </div>
  </div>
</template>
<script>
import { AddTrace, hasKey, EditTrace } from "api/trace";
import { debounce } from "common/js/util";
import clipboard from "clipboard";
import { mapGetters } from "vuex";
export default {
  data() {
    var isUrl = (rule, value, callback) => {
      //   网址检测
      let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?/;
      if (!reg.test(value)) {
        callback(new Error("请输入正确的可直接访问的网址"));
      } else {
        callback();
      }
    };
    var _hasKey = (rule, value, callback) => {
      this.isEdit ? callback() : this._debounce(value, callback);
    };
    return {
      data: {
        key: "",
        url: "",
        desc: "",
        domain: "",
        hash: "",
        degree: 1
      },
      rules: {
        key: [
          { required: true, message: "不能为空", trigger: "blur" },
          { validator: _hasKey, trigger: "change" }
        ],
        url: [
          { required: true, message: "不能为空", trigger: "blur" },
          { validator: isUrl, trigger: "change" }
        ],
        domain: [{ required: true, message: "不能为空", trigger: "blur" }]
      },
      domains: [
        { domain: "www.zastone.com", desc: "美国" },
        {domain: "www.zastone.com.cn", desc: "国内"},
        {domain: "www.meisort.com", desc: '美国'},
        {domain: "www.zastone.net", desc: '俄罗斯'}
      ],
      working: false,
      result: "",
      isEdit: false
    };
  },
  created() {
    this._debounce = this._hasKey();
    if (this.$route.params.data) {
      this.isEdit = true;
      this.data = { ...this.data, ...this.$route.params.data };
      this.result = this.makeResult(this.data.hash);
    }
  },
  mounted() {
    // 添加剪切功能
    this.$nextTick(() => {
      new clipboard(this.$refs.copy.$el);
    });
  },
  computed: {
    ...mapGetters(["id"])
  },
  methods: {
    _hasKey() {
      return debounce((value, callback) => {
        hasKey(value).then(res => {
          if (res.code == 1) {
            callback(new Error("已存在该记录名"));
          } else {
            callback();
          }
        });
      }, 200);
    },
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.isEdit ? this._EditTrace() : this._AddTrace();
        }
      });
    },
    _AddTrace() {
      AddTrace({ ...this.data, ...{ id: this.id } }).then(res => {
        if (res.code == 1) {
          this.result = this.makeResult(res.hash);
          this.$message({
            message: "注册成功",
            type: "success"
          });
        } else {
          this.$message("注册失败");
        }
      });
    },
    _EditTrace() {
      EditTrace({ ...this.data, ...{ id: this.id } }).then(res => {
        if (res.code == 1) {
          this.result = this.makeResult(this.data.hash);

          this.$message({
            message: "修改成功",
            type: "success"
          });
        } else {
          this.$message("修改失败");
        }
      });
    },
    // 短链接
    makeResult(hash) {
      // return `http://localhost:3000/proxy.html#${hash}`
      return `http://${this.data.domain}/statis/proxy.html#${hash}`;
    },
    copy() {
      // document.execCommand('Copy')
      this.$message("复制成功");
    }
  }
};
</script>
<style lang="scss" scoped>
.AddTrace {
  margin-top: 20px;
  width: 50%;
  .form {
    border-bottom: 1px solid #eee;
  }
  .rate {
    margin-top: 10px;
    width: 140px;
  }
  .result {
    padding-top: 15px;
    text-align: left;
    padding-left: 55px;
    font-size: 14px;
  }
  .resultText {
    margin-top: 20px;
  }
}
</style>
