<template>
    <add-trace/>
</template>
<script>
import AddTrace from "components/Index/Admin/Trace/AddTrace";
export default {
  components: {
    AddTrace
  }
};
</script>