<template>
    <div>
        <el-table :data="data" @row-click="rowClick">
            <div slot="empty">
                <i class="el-icon-loading" v-show="loadStatus == 1"></i> {{loadingText}}</div>
            <el-table-column label="记录名" prop="key" align="center"></el-table-column>
            <el-table-column label="推广链接" prop="url" :formatter="urlFormatter" align="center"></el-table-column>
            <el-table-column label="注册时间" prop="time" :formatter="timeFormatter" sortable align="center"></el-table-column>
            <el-table-column label="描述" prop="desc" align="center"></el-table-column>
            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button size="mini" @click.stop="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button size="mini" type="danger" @click.stop="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
import { getAllRegistersById, deleteStat } from "api/trace";
import { mapGetters } from "vuex";
import { formatTime } from "common/js/util";
export default {
  data() {
    return {
      data: [],
      loadStatus: 1
    };
  },
  computed: {
    tableData() {},
    loadingText() {
      return this.loadStatus == 1 ? "加载中" : "暂无数据";
    },
    ...mapGetters(["id"])
  },
  created() {
    this._getAllRegistersById(this.id);
  },
  methods: {
    sortByDegree(arr) {
      // 降序
      arr.sort((a, b) => {
        return a.degree - b.degree == 0 ? b.time - a.time : b.degree - a.degree;
      });
    },
    _getAllRegistersById(id) {
      getAllRegistersById(id).then(res => {
        this.selectActions(res);
      });
    },
    selectActions(res) {
      if (res.code == 1) {
        if (res.data.length == 0) {
          this.loadStatus = 0;
          // 先置空
          this.data = [];
          return;
        }
        this.sortByDegree(res.data);
        this.data = res.data;
      } else {
        this.$message("查询失败");
        this.loadStatus = 0;
      }
    },
    timeFormatter(row, column) {
      return formatTime(row.time);
    },
    urlFormatter(row, column) {
      return decodeURIComponent(row.url);
    },
    // 点击跳转详情
    rowClick(row, event, column) {
      this.$router.push({ name: "TracesPV", params: { key: row.key } });
    },
    handleEdit(index, row) {
      row.url = decodeURIComponent(row.url);
      this.$router.push({
        name: "EditTrace",
        params: { data: row, id: row.owner_id }
      });
    },
    handleDelete(index, row) {
      this.$confirm("此操作将永久删除该主题, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          deleteStat(row.key).then(res => {
            if (res.code == 1) {
              this.data.splice(index, 1);
              this.$message({
                message: "删除成功",
                type: "success"
              });
            } else {
              this.$message({
                message: "删除失败",
                type: "warning"
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  },
  watch: {}
};
</script>