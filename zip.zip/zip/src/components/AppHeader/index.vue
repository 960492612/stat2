<template>
  <div class="header">
    <h2><img src="../../assets/logo.png" alt="zastone"><span>即时通推广</span></h2>
  </div>
</template>
<script>
export default {};
</script>
<style lang="scss" scoped>
.header {
  height: 80px;
  h2 {
    text-align: center;
    line-height: 80px;
    font-size: 18px;
    img {
      width: 80px;
      height: 80px;
      vertical-align: middle;
    }
    span{
      padding-left: 20px;
    }
  }
}
</style>
