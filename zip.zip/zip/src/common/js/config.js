// 数据对应名字
export const LegendNames = {
    readCount: "阅读量",
    thumbsCount: "点赞量",
    commontCount: "评论量",
    relayCount: "转发量",
    showCount: "收藏量"
  };