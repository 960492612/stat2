//节流函数
export function debounce(func, delay) {
    let timer
    return function (...args) {
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            func.apply(this, args)
        }, delay)
    }
}
// fmt: yyyy-MM-dd hh:mm:ss
export function formatTime(str, fmt = 'yyyy-MM-dd') {
    let date = new Date(parseInt(str))
    let obj = {
        'y': date.getFullYear(),
        'M': date.getMonth() + 1,
        'd': date.getDate(),
        'h': date.getHours(),
        'm': date.getMinutes(),
        's': date.getSeconds()
    }

    return fmt.replace(/(y+|M+|d+|h+|m+|s+)/g, function ($0, $1) {
        let time = obj[$1.substr(0, 1)] + ''
        time = time.length == 1 ? ('0' + time) : time;
        return time.substr(time.length - $1.length, $1.length)
    })
}

export function isInDateRange(s, e, c) {
    return c.getTime() >= s.getTime() && c.getTime() <= e.getTime();
}

export const shortcuts = [
    {
      text: "最近一周",
      onClick(picker) {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
        picker.$emit("pick", [start, end]);
      }
    },
    {
      text: "最近一个月",
      onClick(picker) {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
        picker.$emit("pick", [start, end]);
      }
    },
    {
      text: "最近三个月",
      onClick(picker) {
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
        picker.$emit("pick", [start, end]);
      }
    }
  ]