<template>
  <div id="app">

    <router-view/>
  </div>
</template>

<script>
import { mapGetters,mapMutations } from "vuex";
import Index from "@/components/Index";
import Vue from 'vue'
export default {
  name: "app",
  created() {
    if (this.isLogin) {
      this.init();
    }
    
  },
  computed: {
    isManage() {
      return this.pl == 5;
    },
    ...mapGetters(["router", "pl", "isLogin", "currentLocation"])
  },
  methods: {
    init() {
      
      let routes = [
        {
          path: "/",
          name: "Index",
          component: Index,
          // redirect: {name: 'Results'},
          meta: { requireAuth: true },
          children: this.initRouter(
            JSON.parse(JSON.stringify(this.router)),
            `./components/Index/${this.isManage ? "Manage" : "Admin"}`
          )
        }
      ];

      this.$router.addRoutes(routes);
      this.$nextTick(()=>{
        this.$router.push({path: this.currentLocation})
      })
      
    },
    // 动态添加递归路由
    initRouter(router, path) {
      router.map(item => {
        // let _path = path;
        let _path = `${path}/${item.name}`;
        item.component = res => {
          import(_path + "").then(module => {
            res(module);
          });
        };
        if (item.children && item.children.length) {
          this.initRouter(item.children, _path);
        }
      });
      return router;
    },
    ...mapMutations({
      "setCurrentLocation": 'SET_CURRENT_LOCATION'
    })
  },
  watch: {
    isLogin(newVal) {
      this.init();
    },
    $route(newVal){
      this.setCurrentLocation(newVal.fullPath)
    }
  }
};
</script>

<style>
#app {
  font-family:'微软雅黑', "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  height: 100%;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
