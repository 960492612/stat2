import axios from 'axios'
import { apiBaseUrl } from '@/config'
export function getProducts() {
    return axios.get(apiBaseUrl + 'getProducts').then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getProductCates() {
    return axios.get(apiBaseUrl + 'getProductCates').then((res) => {
        return Promise.resolve(res.data)
    })
}
export function addProduct(data) {
    return axios.post(apiBaseUrl + 'addProduct', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function editProduct(data) {
    return axios.post(apiBaseUrl + 'editProduct', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function hasProductKey(data) {
    return axios.get(apiBaseUrl + 'hasProductKey', {params:{data}} ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function deleteProduct(data) {
    return axios.post(apiBaseUrl + 'deleteProduct', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}

