import axios from 'axios'
import { apiBaseUrl } from '@/config'
export function login(data) {
    return axios.post(apiBaseUrl + 'login',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function isLogin(data) {
    return axios.get(apiBaseUrl + 'isLogin',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}
