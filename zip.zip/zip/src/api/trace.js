import axios from 'axios'
import { apiBaseUrl_trace } from '@/config'
export function getAllRegisters() {
    return axios.get(apiBaseUrl_trace + 'getAllRegisters').then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getAllRegistersById(id) {
    return axios.get(apiBaseUrl_trace + 'getAllRegistersById', { params: { id } }).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function deleteStat(key) {
    return axios.post(apiBaseUrl_trace + 'deleteStat',  {key} ).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getAllRegistersByPlatform(pf) {
    return axios.get(apiBaseUrl_trace + 'getAllRegistersByPlatform', { params: { pf } }).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function AddTrace(data) {
    return axios.post(apiBaseUrl_trace + 'registerStat', data).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function hasKey(data) {
    return axios.get(apiBaseUrl_trace + 'hasKey', { params: { key: data } }).then((res) => {
        return Promise.resolve(res.data)
    })
}


export function EditTrace(data) {
    return axios.post(apiBaseUrl_trace + 'updateStat', data).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getAllVisitsByOid(data) {
    return axios.get(apiBaseUrl_trace + 'getAllVisitsByOid', { params: { id: data } }).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getAllVisitsByPlatform(pf) {
    return axios.get(apiBaseUrl_trace + 'getAllVisitsByPlatform', { params: { pf } }).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getAllVisits() {
    return axios.get(apiBaseUrl_trace + 'getAllVisits').then((res) => {
        return Promise.resolve(res.data)
    })
}