import axios from 'axios'
import { apiBaseUrl } from '@/config'
export function getSubjectsByAid(aid, page, size) {
    return axios.get(apiBaseUrl + 'getSubjectsByAid', {params:{aid, page, size}}).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getSubjectsTotal(aid) {
    return axios.get(apiBaseUrl + 'getSubjectsTotal', {params:{aid}}).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function addSubject(data) {
    return axios.post(apiBaseUrl + 'addSubject',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function editSubject(data) {
    return axios.post(apiBaseUrl + 'editSubject',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function deleteSubject(data) {
    return axios.post(apiBaseUrl + 'deleteSubject',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getSubjectsBySid(sid) {
    return axios.get(apiBaseUrl + 'getSubjectsBySid',  {params:{sid}}  ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getSubjectsByQuery(type, query, id) {
    return axios.get(apiBaseUrl + 'getSubjectsByQuery',  {params:{type, query, id}}  ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function addRecords(data) {
    return axios.post(apiBaseUrl + 'addRecords',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}


export function getSubjectsRocordBySid(sid) {
    return axios.get(apiBaseUrl + 'getSubjectsRocordBySid',  {params:{sid}}  ).then((res) => {
        return Promise.resolve(res.data)
    })
}


export function toggleSubject(data) {
    return axios.post(apiBaseUrl + 'toggleSubject',  data  ).then((res) => {
        return Promise.resolve(res.data)
    })
}


export function searchSubjectOnDays(recordDays, publishDays, id) {
    return axios.get(apiBaseUrl + 'searchSubjectOnDays',  {params:{recordDays, publishDays, id}}  ).then((res) => {
        return Promise.resolve(res.data)
    })
}