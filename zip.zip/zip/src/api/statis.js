import axios from 'axios'
import { apiBaseUrl } from '@/config'

export function getRecords(params) {
    return axios.get(apiBaseUrl + 'getRecords', { params: {params} }).then((res) => {
        return Promise.resolve(res.data)
    })
}