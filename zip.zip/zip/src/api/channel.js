import axios from 'axios'
import { apiBaseUrl } from '@/config'
export function getChannelsByOwner(owner) {
    return axios.get(apiBaseUrl + 'getChannelsByOwner', {params:{owner}}).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getTopChannelsByOwner(owner, pid) {
    return axios.get(apiBaseUrl + 'getTopChannelsByOwner', {params:{owner, pid}}).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getSubChannelsByOwnerAndId(owner, ids) {
    return axios.get(apiBaseUrl + 'getSubChannelsByOwnerAndId', {params:{owner, ids}}).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function addChannels(data) {
    return axios.post(apiBaseUrl + 'addChannels', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function editChannels(data) {
    return axios.post(apiBaseUrl + 'editChannels', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function deleteChannel(data) {
    return axios.post(apiBaseUrl + 'deleteChannel', data ).then((res) => {
        return Promise.resolve(res.data)
    })
}