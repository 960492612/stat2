import axios from 'axios'
import { apiBaseUrl } from '@/config'
export function hasUser(data) {
    return axios.get(apiBaseUrl + 'hasUser', { params: { data } }).then((res) => {
        return Promise.resolve(res.data)
    })
}

export function editUser(data) {
    return axios.post(apiBaseUrl + 'editUser', data).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function addUser(data) {
    return axios.post(apiBaseUrl + 'addUser', data).then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getAdmins() {
    return axios.get(apiBaseUrl + 'getAdmins').then((res) => {
        return Promise.resolve(res.data)
    })
}
export function getAllUsers() {
    return axios.get(apiBaseUrl + 'getAllUsers').then((res) => {
        return Promise.resolve(res.data)
    })
}

export function getPlatforms() {
    return axios.get(apiBaseUrl + 'getPlatforms').then((res) => {
        return Promise.resolve(res.data)
    })
}

export function deleteUser(data) {
    return axios.post(apiBaseUrl + 'deleteUser', data).then((res) => {
        return Promise.resolve(res.data)
    })
}